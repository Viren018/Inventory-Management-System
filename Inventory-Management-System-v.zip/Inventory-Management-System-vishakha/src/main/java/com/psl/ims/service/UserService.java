package com.psl.ims.service;

import com.psl.ims.entity.User;

public interface UserService {

	public User save(User user);
	
	//public User getUserByEmail(String email);
	
}
